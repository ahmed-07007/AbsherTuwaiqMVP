import { base44 } from './base44Client';


export const MedicalHistory = base44.entities.MedicalHistory;

export const Paramedic = base44.entities.Paramedic;

export const EmergencyRequest = base44.entities.EmergencyRequest;



// auth sdk:
export const User = base44.auth;