import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Phone, Heart, Brain, Wind, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function EmergencyRequest() {
  const navigate = useNavigate();
  const [selectedCondition, setSelectedCondition] = useState('');

  const conditions = [
    { id: 'heart_attack', label: 'أزمة قلبية', icon: Heart, color: 'bg-red-100 text-red-600 border-red-200' },
    { id: 'brain_stroke', label: 'سكتة دماغية', icon: Brain, color: 'bg-purple-100 text-purple-600 border-purple-200' },
    { id: 'breathing_problems', label: 'مشاكل بالتنفس', icon: Wind, color: 'bg-blue-100 text-blue-600 border-blue-200' },
    { id: 'fainting', label: 'إغماء', icon: Users, color: 'bg-amber-100 text-amber-600 border-amber-200' },
  ];

  const handleEmergencyCall = () => {
    if (selectedCondition) {
      // This would trigger the emergency alert to nearby paramedics
      navigate(createPageUrl('EmergencyAlert') + `?condition=${selectedCondition}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-white">
      {/* Header */}
      <div className="sticky top-0 bg-white/80 backdrop-blur-sm border-b border-gray-100 px-4 py-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition">
          <ArrowRight className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">هل تحتاج إلى مساعدة طارئة؟</h1>
      </div>

      <div className="p-6">
        {/* Emergency Icon */}
        <motion.div 
          className="flex justify-center mb-6"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4 }}
        >
          <div className="w-24 h-24 rounded-full bg-red-500 flex items-center justify-center shadow-lg shadow-red-200">
            <Phone className="w-12 h-12 text-white" />
          </div>
        </motion.div>

        <p className="text-center text-gray-600 mb-6">اضغط على كل الأعراض التالية</p>

        {/* Condition Selection */}
        <motion.div 
          className="grid grid-cols-2 gap-3 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          {conditions.map((condition) => {
            const Icon = condition.icon;
            return (
              <button
                key={condition.id}
                onClick={() => setSelectedCondition(condition.id)}
                className={`p-4 rounded-xl border-2 transition-all ${
                  selectedCondition === condition.id
                    ? 'border-red-500 bg-red-50 shadow-md'
                    : `border-gray-200 bg-white hover:border-gray-300 ${condition.color.split(' ')[0]}`
                }`}
              >
                <div className="flex flex-col items-center gap-2">
                  <Icon className={`w-6 h-6 ${selectedCondition === condition.id ? 'text-red-500' : condition.color.split(' ')[1]}`} />
                  <span className={`text-sm font-medium ${selectedCondition === condition.id ? 'text-red-700' : 'text-gray-700'}`}>
                    {condition.label}
                  </span>
                </div>
              </button>
            );
          })}
        </motion.div>

        {/* Emergency Button */}
        <Button
          onClick={handleEmergencyCall}
          disabled={!selectedCondition}
          className="w-full h-14 text-lg font-bold bg-red-600 hover:bg-red-700 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
        >
          طلب إسعاف
        </Button>
      </div>
    </div>
  );
}