import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Phone, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CallingCenter() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate(createPageUrl('Home'));
    }, 3000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 text-white flex flex-col items-center justify-center p-6">
      <motion.div 
        className="text-center"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
      >
        {/* Animated Phone Icon */}
        <motion.div
          className="w-32 h-32 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-8"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Phone className="w-16 h-16 text-white" />
        </motion.div>

        {/* Message */}
        <h1 className="text-2xl font-bold mb-4">يتم الاتصال بمركز الإسعاف الأقرب</h1>
        <p className="text-blue-200 mb-8">الرجاء الانتظار...</p>

        {/* Loading Dots */}
        <div className="flex justify-center gap-2">
          <motion.div
            className="w-3 h-3 bg-white rounded-full"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: 0 }}
          />
          <motion.div
            className="w-3 h-3 bg-white rounded-full"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: 0.2 }}
          />
          <motion.div
            className="w-3 h-3 bg-white rounded-full"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: 0.4 }}
          />
        </div>
      </motion.div>
    </div>
  );
}