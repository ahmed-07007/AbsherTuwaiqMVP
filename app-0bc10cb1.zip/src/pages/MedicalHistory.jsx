import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Droplet, Stethoscope, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { motion } from 'framer-motion';

const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const diseases = [
  { id: 'diabetes', label: 'السكري' },
  { id: 'heart', label: 'أمراض القلب' },
  { id: 'pressure', label: 'ضغط الدم' },
  { id: 'asthma', label: 'السكري' },
  { id: 'kidney', label: 'أمراض الكلى' },
  { id: 'allergy', label:'الصرع' },
];

const regions = [
  'الرياض',
  'مكة المكرمة',
  'المدينة المنورة',
  'القصيم',
  'المنطقة الشرقية',
  'عسير',
  'تبوك',
  'حائل',
  'الحدود الشمالية',
  'الجوف',
  'جازان',
  'الباحة',
  'نجران'
];

export default function MedicalHistoryPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    bloodType: '',
    selectedDiseases: [],
    region: '',
    nearestCenter: '',
  });

  const handleDiseaseToggle = (diseaseId) => {
    setFormData(prev => ({
      ...prev,
      selectedDiseases: prev.selectedDiseases.includes(diseaseId)
        ? prev.selectedDiseases.filter(d => d !== diseaseId)
        : [...prev.selectedDiseases, diseaseId]
    }));
  };

  const handleSubmit = () => {
    // Save logic here
    navigate(createPageUrl('Home'));
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition">
          <ArrowRight className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">الحالة المرضية</h1>
      </div>

      <motion.div 
        className="p-6 space-y-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Blood Type */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Droplet className="w-5 h-5 text-red-500" />
            <Label className="text-base font-semibold text-gray-800">فصيلة الدم</Label>
          </div>
          <Select value={formData.bloodType} onValueChange={(v) => setFormData(prev => ({ ...prev, bloodType: v }))}>
            <SelectTrigger className="h-12 text-base">
              <SelectValue placeholder="اختر فصيلة الدم" />
            </SelectTrigger>
            <SelectContent>
              {bloodTypes.map(type => (
                <SelectItem key={type} value={type}>{type}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Diseases */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-blue-500" />
            <Label className="text-base font-semibold text-gray-800">هل لديك أي من الأمراض ألتاليه؟</Label>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {diseases.map(disease => (
              <div
                key={disease.id}
                onClick={() => handleDiseaseToggle(disease.id)}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  formData.selectedDiseases.includes(disease.id)
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Checkbox 
                    checked={formData.selectedDiseases.includes(disease.id)}
                    className="pointer-events-none"
                  />
                  <span className="font-medium text-gray-700">{disease.label}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Region */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-purple-500" />
            <Label className="text-base font-semibold text-gray-800">المنطقة</Label>
          </div>
          <Select value={formData.region} onValueChange={(v) => setFormData(prev => ({ ...prev, region: v }))}>
            <SelectTrigger className="h-12 text-base">
              <SelectValue placeholder="اختر المنطقة" />
            </SelectTrigger>
            <SelectContent>
              {regions.map(region => (
                <SelectItem key={region} value={region}>{region}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Nearest Center */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-500" />
            <Label className="text-base font-semibold text-gray-800">اختر مركز إسعاف</Label>
          </div>
          <a
            href="https://www.google.com/maps/search/مراكز+الإسعاف+في+الرياض"
            target="_blank"
            rel="noopener noreferrer"
            className="block"
          >
            <Button
              type="button"
              variant="outline"
              className="w-full h-12 text-base justify-start text-blue-600 hover:text-blue-700 hover:bg-blue-50"
            >
              <MapPin className="w-5 h-5 ml-2" />
              اضغط لعرض مراكز الإسعاف
            </Button>
          </a>
        </div>

        {/* Submit Button */}
        <Button
          onClick={handleSubmit}
          className="w-full h-14 text-lg font-semibold bg-blue-600 hover:bg-blue-700 rounded-xl"
        >
          حفظ البيانات
        </Button>
      </motion.div>
    </div>
  );
}