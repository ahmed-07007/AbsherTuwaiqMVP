import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';

export default function NafathLogin() {
  const navigate = useNavigate();
  const [nationalId, setNationalId] = useState('');

  const handleLogin = () => {
    if (nationalId.length === 10) {
      navigate(createPageUrl('ParamedicData') + `?nationalId=${nationalId}`);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition">
          <ArrowRight className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">نفاذ</h1>
      </div>

      <motion.div 
        className="p-6 flex flex-col items-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Nafath Logo Area */}
        <div className="w-full max-w-sm mt-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-emerald-700 mb-2">نفاذ</h2>
            <p className="text-gray-500 text-sm">مرحباً بك في الدخول الموحد الوطني</p>
            <p className="text-gray-400 text-xs mt-1">الرجاء إدخال الهوية الوطنية/هوية مقيم ثم الضغط على تسجيل الدخول</p>
          </div>

          {/* ID Input */}
          <div className="space-y-4">
            <div className="relative">
              <Input
                type="text"
                value={nationalId}
                onChange={(e) => setNationalId(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="رقم الهوية/الإقامة/الحدود"
                className="h-14 text-base pr-12 text-right"
                maxLength={10}
              />
              <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>

            <Button
              onClick={handleLogin}
              disabled={nationalId.length !== 10}
              className="w-full h-14 text-lg font-semibold bg-emerald-600 hover:bg-emerald-700 rounded-xl disabled:opacity-50"
            >
              تسجيل الدخول
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}