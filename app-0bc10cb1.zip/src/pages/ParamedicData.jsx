import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, User, CreditCard, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { motion } from 'framer-motion';

export default function ParamedicData() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const nationalId = urlParams.get('nationalId') || '';

  const [formData, setFormData] = useState({
    name: 'محمد بن علي',
    nationalId: nationalId || '1235967890',
    inSameArea: null,
    needsSiren: null,
    selectedVehicle: '',
  });

  const vehicles = [
    { id: 'v1', name: 'تويوتا كامري 2022', plate: 'أ ب ج 1234' },
    { id: 'v2', name: 'هوندا أكورد 2021', plate: 'د هـ و 5678' },
  ];

  const handleSubmit = () => {
    // Save logic here
    navigate(createPageUrl('PermitRequest'));
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition">
          <ArrowRight className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">صفحة بيانات المسعف</h1>
      </div>

      <motion.div 
        className="p-6 space-y-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Paramedic Info */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-800">بيانات المسعف</h2>
          
          <div className="space-y-3">
            <div className="space-y-2">
              <Label className="text-sm text-gray-600">الاسم</Label>
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <User className="w-5 h-5 text-gray-400" />
                <span className="font-medium text-gray-800">{formData.name}</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm text-gray-600">رقم الهوية</Label>
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                <CreditCard className="w-5 h-5 text-gray-400" />
                <span className="font-medium text-gray-800 font-mono">{formData.nationalId}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Same Area Question */}
        <div className="space-y-3">
          <Label className="text-base font-semibold text-gray-800">هل تقيم في نفس منطقة المريض؟</Label>
          <div className="flex items-center gap-3">
            <Checkbox
              id="same-area"
              checked={formData.inSameArea === true}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, inSameArea: checked }))}
            />
            <Label htmlFor="same-area" className="cursor-pointer">نعم، أقيم في نفس المنطقة</Label>
          </div>
        </div>

        {/* Siren Request */}
        <div className="space-y-3">
          <Label className="text-base font-semibold text-gray-800">طلب جهاز الإنذار</Label>
          <div className="flex items-center gap-3">
            <Checkbox
              id="needs-siren"
              checked={formData.needsSiren === true}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, needsSiren: checked }))}
            />
            <Label htmlFor="needs-siren" className="cursor-pointer">أحتاج جهاز إنذار</Label>
          </div>
        </div>

        {/* Vehicle Selection */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Car className="w-5 h-5 text-blue-500" />
            <Label className="text-base font-semibold text-gray-800">مركباتي</Label>
          </div>
          <div className="space-y-2">
            {vehicles.map(vehicle => (
              <div
                key={vehicle.id}
                onClick={() => setFormData(prev => ({ ...prev, selectedVehicle: vehicle.id }))}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  formData.selectedVehicle === vehicle.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-800">{vehicle.name}</p>
                    <p className="text-sm text-gray-500">{vehicle.plate}</p>
                  </div>
                  <div className={`w-5 h-5 rounded-full border-2 ${
                    formData.selectedVehicle === vehicle.id
                      ? 'border-blue-500 bg-blue-500'
                      : 'border-gray-300'
                  }`}>
                    {formData.selectedVehicle === vehicle.id && (
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <Button
          onClick={handleSubmit}
          className="w-full h-14 text-lg font-semibold bg-blue-600 hover:bg-blue-700 rounded-xl"
        >
          طلب تصريح
        </Button>
      </motion.div>
    </div>
  );
}