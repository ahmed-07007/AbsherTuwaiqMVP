import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CheckCircle, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function TripComplete() {
  const navigate = useNavigate();

  const handleComplete = () => {
    navigate(createPageUrl('MedicalReport'));
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6">
      <motion.div 
        className="text-center max-w-sm"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
      >
        {/* Success Icon */}
        <motion.div 
          className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2, type: 'spring' }}
        >
          <CheckCircle className="w-14 h-14 text-emerald-500" />
        </motion.div>

        <h1 className="text-2xl font-bold text-gray-800 mb-2">تم الوصول إلى الوجهة</h1>
        <p className="text-gray-500 mb-8">شكراً لك على خدمتك الإنسانية</p>

        <Button
          onClick={handleComplete}
          className="w-full h-14 text-lg font-bold bg-red-500 hover:bg-red-600 rounded-xl"
        >
          إتمام الرحلة
        </Button>
      </motion.div>
    </div>
  );
}