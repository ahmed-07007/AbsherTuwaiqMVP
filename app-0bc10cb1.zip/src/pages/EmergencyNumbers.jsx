import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Phone, Ambulance, Shield, Flame } from 'lucide-react';
import { motion } from 'framer-motion';

export default function EmergencyNumbers() {
  const navigate = useNavigate();

  const emergencyNumbers = [
    { name: 'الإسعاف', number: '997', icon: Ambulance, color: 'bg-red-500' },
    { name: 'الشرطة', number: '999', icon: Shield, color: 'bg-blue-500' },
    { name: 'الدفاع المدني', number: '998', icon: Flame, color: 'bg-orange-500' },
    { name: 'الطوارئ الموحد', number: '911', icon: Phone, color: 'bg-emerald-500' },
  ];

  const handleCall = (number) => {
    window.location.href = `tel:${number}`;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition">
          <ArrowRight className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">أرقام الطوارئ</h1>
      </div>

      <motion.div 
        className="p-6 space-y-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {emergencyNumbers.map((item, index) => {
          const Icon = item.icon;
          return (
            <motion.button
              key={item.number}
              onClick={() => handleCall(item.number)}
              className="w-full p-4 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition-all flex items-center gap-4"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className={`w-14 h-14 ${item.color} rounded-xl flex items-center justify-center`}>
                <Icon className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 text-right">
                <p className="font-semibold text-gray-800">{item.name}</p>
                <p className="text-2xl font-bold text-gray-900 font-mono">{item.number}</p>
              </div>
              <Phone className="w-6 h-6 text-gray-400" />
            </motion.button>
          );
        })}
      </motion.div>
    </div>
  );
}