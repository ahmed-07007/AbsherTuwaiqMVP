import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Heart, Brain, Wind, Droplet, Bone, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export default function FirstAid() {
  const navigate = useNavigate();

  const firstAidTopics = [
    { title: 'الإنعاش القلبي', icon: Heart, color: 'bg-red-100 text-red-600' },
    { title: 'السكتة الدماغية', icon: Brain, color: 'bg-purple-100 text-purple-600' },
    { title: 'صعوبة التنفس', icon: Wind, color: 'bg-blue-100 text-blue-600' },
    { title: 'النزيف', icon: Droplet, color: 'bg-rose-100 text-rose-600' },
    { title: 'الكسور', icon: Bone, color: 'bg-amber-100 text-amber-600' },
    { title: 'الصدمة الكهربائية', icon: Zap, color: 'bg-yellow-100 text-yellow-600' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition">
          <ArrowRight className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-bold text-gray-800">الإسعافات الأولية</h1>
      </div>

      <motion.div 
        className="p-6 grid grid-cols-2 gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {firstAidTopics.map((topic, index) => {
          const Icon = topic.icon;
          return (
            <motion.button
              key={topic.title}
              className={`p-6 rounded-2xl ${topic.color.split(' ')[0]} hover:shadow-md transition-all flex flex-col items-center gap-3`}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Icon className={`w-10 h-10 ${topic.color.split(' ')[1]}`} />
              <span className={`text-sm font-semibold ${topic.color.split(' ')[1]}`}>{topic.title}</span>
            </motion.button>
          );
        })}
      </motion.div>
    </div>
  );
}