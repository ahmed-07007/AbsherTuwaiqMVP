import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MapPin, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function TripMap() {
  const navigate = useNavigate();
  const [patientReached, setPatientReached] = useState(false);
  const [isTransferable, setIsTransferable] = useState(null);

  const handleStartNavigation = () => {
    // This would open maps navigation
    setPatientReached(true);
  };

  const handleTransferDecision = (transferable) => {
    setIsTransferable(transferable);
    if (transferable) {
      // Navigate to hospital map
      navigate(createPageUrl('HospitalMap'));
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center justify-between">
        <h1 className="text-lg font-bold text-gray-800">الخريطة</h1>
        <span className="text-sm text-gray-500">قرار النقل</span>
      </div>

      <div className="p-6">
        {!patientReached ? (
          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {/* Map Placeholder */}
            <div className="h-64 bg-gray-100 rounded-2xl flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-b from-blue-50 to-blue-100" />
              <div className="relative z-10 text-center">
                <MapPin className="w-12 h-12 text-red-500 mx-auto mb-2" />
                <p className="text-gray-600 font-medium">موقع المريض</p>
              </div>
            </div>

            <Button
              onClick={handleStartNavigation}
              className="w-full h-14 text-lg font-bold bg-blue-600 hover:bg-blue-700 rounded-xl flex items-center justify-center gap-2"
            >
              <Navigation className="w-5 h-5" />
              ابدأ الخريطة
            </Button>
          </motion.div>
        ) : (
          <motion.div 
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold text-gray-800 mb-2">هل ترغب في نقل المريض؟</h2>
              <p className="text-gray-500 text-sm">بعد تقديم الإسعافات الأولية</p>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => handleTransferDecision(true)}
                className="w-full h-14 text-lg font-bold bg-emerald-500 hover:bg-emerald-600 rounded-xl"
              >
                نعم
              </Button>
              <Button
                onClick={() => handleTransferDecision(false)}
                variant="outline"
                className="w-full h-14 text-lg font-medium border-gray-200 text-gray-600 rounded-xl"
              >
                لا
              </Button>
            </div>

            {isTransferable === true && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-4 bg-blue-50 rounded-xl"
              >
                <p className="text-blue-700 text-center font-medium">جاري تحديد أقرب مستشفى...</p>
              </motion.div>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}