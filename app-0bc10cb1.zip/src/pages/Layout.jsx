
import React from 'react';

export default function Layout({ children }) {
  return (
    <div dir="rtl" className="min-h-screen bg-gray-50 font-sans">
      <style>{`
        :root {
          --emergency-red: #DC2626;
          --primary-blue: #2563EB;
          --soft-gray: #F3F4F6;
        }
        body {
          font-family: 'Inter', 'Segoe UI', Tahoma, sans-serif;
        }
      `}</style>
      <div className="max-w-md mx-auto bg-white min-h-screen shadow-xl">
        {children}
      </div>
    </div>
  );
}
