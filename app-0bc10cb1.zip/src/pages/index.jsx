import Layout from "./Layout.jsx";

import Home from "./Home";

import MedicalHistory from "./MedicalHistory";

import NafathLogin from "./NafathLogin";

import ParamedicData from "./ParamedicData";

import EmergencyRequest from "./EmergencyRequest";

import EmergencyAlert from "./EmergencyAlert";

import TripAccepted from "./TripAccepted";

import TripMap from "./TripMap";

import TripComplete from "./TripComplete";

import MedicalReport from "./MedicalReport";

import EmergencyNumbers from "./EmergencyNumbers";

import FirstAid from "./FirstAid";

import PermitRequest from "./PermitRequest";

import CallingCenter from "./CallingCenter";

import HospitalMap from "./HospitalMap";

import ReportSubmitted from "./ReportSubmitted";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    MedicalHistory: MedicalHistory,
    
    NafathLogin: NafathLogin,
    
    ParamedicData: ParamedicData,
    
    EmergencyRequest: EmergencyRequest,
    
    EmergencyAlert: EmergencyAlert,
    
    TripAccepted: TripAccepted,
    
    TripMap: TripMap,
    
    TripComplete: TripComplete,
    
    MedicalReport: MedicalReport,
    
    EmergencyNumbers: EmergencyNumbers,
    
    FirstAid: FirstAid,
    
    PermitRequest: PermitRequest,
    
    CallingCenter: CallingCenter,
    
    HospitalMap: HospitalMap,
    
    ReportSubmitted: ReportSubmitted,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/MedicalHistory" element={<MedicalHistory />} />
                
                <Route path="/NafathLogin" element={<NafathLogin />} />
                
                <Route path="/ParamedicData" element={<ParamedicData />} />
                
                <Route path="/EmergencyRequest" element={<EmergencyRequest />} />
                
                <Route path="/EmergencyAlert" element={<EmergencyAlert />} />
                
                <Route path="/TripAccepted" element={<TripAccepted />} />
                
                <Route path="/TripMap" element={<TripMap />} />
                
                <Route path="/TripComplete" element={<TripComplete />} />
                
                <Route path="/MedicalReport" element={<MedicalReport />} />
                
                <Route path="/EmergencyNumbers" element={<EmergencyNumbers />} />
                
                <Route path="/FirstAid" element={<FirstAid />} />
                
                <Route path="/PermitRequest" element={<PermitRequest />} />
                
                <Route path="/CallingCenter" element={<CallingCenter />} />
                
                <Route path="/HospitalMap" element={<HospitalMap />} />
                
                <Route path="/ReportSubmitted" element={<ReportSubmitted />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}