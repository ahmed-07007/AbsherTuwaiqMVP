import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, MapPin, User, Stethoscope } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function EmergencyAlert() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const condition = urlParams.get('condition') || 'heart_attack';

  const conditionLabels = {
    heart_attack: 'أزمة قلبية',
    brain_stroke: 'سكتة دماغية',
    breathing_problems: 'مشاكل بالتنفس',
    fainting: 'إغماء',
  };

  // Mock patient data
  const patientData = {
    name: 'أحمد محمد',
    condition: conditionLabels[condition] || 'حالة طارئة',
    healthStatus: 'السكري',
    location: 'شارع الملك عبدالله، جدة',
  };

  const handleAccept = () => {
    navigate(createPageUrl('TripAccepted'));
  };

  const handleTransfer = () => {
    // Transfer to nearest emergency center
    navigate(createPageUrl('CallingCenter'));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 text-white">
      {/* Header */}
      <div className="px-4 py-6">
        <div className="flex items-center justify-between">
          <span className="text-sm text-blue-200">09:41</span>
        </div>
      </div>

      <motion.div 
        className="p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Alert Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">إنذار إسعاف</h1>
          <div className="w-16 h-1 bg-blue-400 mx-auto rounded-full" />
        </div>

        {/* Patient Info Card */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 space-y-4 mb-8">
          <div className="flex items-center gap-3">
            <User className="w-5 h-5 text-blue-300" />
            <div>
              <p className="text-blue-200 text-sm">اسم المريض</p>
              <p className="font-semibold text-lg">{patientData.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Stethoscope className="w-5 h-5 text-blue-300" />
            <div>
              <p className="text-blue-200 text-sm">الحالة الصحية</p>
              <p className="font-semibold">{patientData.healthStatus}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <MapPin className="w-5 h-5 text-blue-300" />
            <div>
              <p className="text-blue-200 text-sm">الموقع</p>
              <p className="font-semibold">{patientData.location}</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={handleAccept}
            className="w-full h-14 text-lg font-bold bg-emerald-500 hover:bg-emerald-600 rounded-xl"
          >
            قبول
          </Button>
          <Button
            onClick={handleTransfer}
            variant="outline"
            className="w-full h-14 text-lg font-bold bg-white/10 hover:bg-white/20 border-white/20 text-white rounded-xl"
          >
            تحويل
          </Button>
        </div>
      </motion.div>
    </div>
  );
}