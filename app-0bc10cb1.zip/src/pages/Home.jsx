import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Phone, Plus, FileText, UserPlus, ChevronLeft } from 'lucide-react';
import ServiceCard from '@/components/home/ServiceCard';
import EmergencyButton from '@/components/home/EmergencyButton';
import { motion } from 'framer-motion';

export default function Home() {
  const navigate = useNavigate();

  const services = [
    { icon: Phone, title: 'أرقام الطوارئ', color: 'bg-emerald-500', page: 'EmergencyNumbers' },
    { icon: Plus, title: 'الإسعافات الأولية', color: 'bg-blue-500', page: 'FirstAid' },
    { icon: FileText, title: 'التاريخ الطبي', color: 'bg-purple-500', page: 'MedicalHistory' },
    { icon: UserPlus, title: 'إضافة مسعف', color: 'bg-amber-500', page: 'NafathLogin' },
  ];

  const handleEmergencyPress = () => {
    navigate(createPageUrl('EmergencyRequest'));
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Emergency Button Section - Moved to Top */}
      <div className="flex flex-col items-center justify-center py-12 pt-16">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <EmergencyButton onClick={handleEmergencyPress} />
        </motion.div>
        <p className="mt-6 text-gray-600 font-medium">اضغط لطلب الطوارئ</p>
      </div>

      {/* Header */}
      <div className="px-6 pt-4 pb-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-800">أبرز الخدمات</h2>
          <button className="flex items-center gap-1 text-sm text-blue-600 font-medium">
            عرض الكل
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Services Grid */}
      <motion.div 
        className="px-4 grid grid-cols-4 gap-2 flex-1"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {services.map((service, index) => (
          <ServiceCard key={index} {...service} />
        ))}
      </motion.div>

      {/* Bottom Navigation Indicator */}
      <div className="pb-8 flex justify-center">
        <div className="w-32 h-1 bg-gray-200 rounded-full" />
      </div>
    </div>
  );
}