import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MapPin, Navigation, Hospital } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function HospitalMap() {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate(createPageUrl('TripComplete'));
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-4 flex items-center justify-between">
        <h1 className="text-lg font-bold text-gray-800">خريطة أقرب مستشفى</h1>
      </div>

      <motion.div 
        className="p-6 space-y-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Map Placeholder */}
        <div className="h-96 bg-gradient-to-b from-green-50 to-green-100 rounded-2xl flex items-center justify-center relative overflow-hidden shadow-md">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Hospital className="w-20 h-20 text-green-600 mx-auto mb-4" />
              </motion.div>
              <p className="text-green-700 font-bold text-lg">أقرب مستشفى</p>
              <p className="text-green-600 text-sm mt-2">مستشفى الملك فيصل - 3.2 كم</p>
            </div>
          </div>
        </div>

        {/* Hospital Info */}
        <div className="bg-gray-50 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-3">
            <Hospital className="w-6 h-6 text-green-600" />
            <div>
              <p className="text-sm text-gray-500">اسم المستشفى</p>
              <p className="font-bold text-gray-800">مستشفى الملك فيصل التخصصي</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <MapPin className="w-6 h-6 text-green-600" />
            <div>
              <p className="text-sm text-gray-500">الموقع</p>
              <p className="font-semibold text-gray-800">شارع التخصصي، الرياض</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Navigation className="w-6 h-6 text-green-600" />
            <div>
              <p className="text-sm text-gray-500">المسافة</p>
              <p className="font-semibold text-gray-800">3.2 كم - 8 دقائق تقريباً</p>
            </div>
          </div>
        </div>

        {/* Navigate Button */}
        <Button
          onClick={handleNavigate}
          className="w-full h-14 text-lg font-bold bg-green-600 hover:bg-green-700 rounded-xl flex items-center justify-center gap-2"
        >
          <Navigation className="w-5 h-5" />
          ابدأ الملاحة
        </Button>
      </motion.div>
    </div>
  );
}