import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function TripAccepted() {
  const navigate = useNavigate();
  const [sirenEnabled, setSirenEnabled] = useState(false);

  const handleEnableSiren = () => {
    setSirenEnabled(true);
    navigate(createPageUrl('TripMap'));
  };

  const handleLater = () => {
    navigate(createPageUrl('TripMap'));
  };

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6">
      <motion.div 
        className="text-center max-w-sm"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
      >
        {/* Success Icon */}
        <motion.div 
          className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2, type: 'spring' }}
        >
          <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </motion.div>

        <h1 className="text-2xl font-bold text-gray-800 mb-2">تم قبول الرحلة الإسعافية</h1>
        <p className="text-gray-500 mb-8">تشغيل الصفارة ؟</p>

        {/* Siren Options */}
        <div className="space-y-3">
          <Button
            onClick={handleLater}
            variant="outline"
            className="w-full h-14 text-lg font-medium border-gray-200 text-gray-600 rounded-xl"
          >
            لاحقا
          </Button>
          <Button
            onClick={handleEnableSiren}
            className="w-full h-14 text-lg font-bold bg-blue-600 hover:bg-blue-700 rounded-xl flex items-center justify-center gap-2"
          >
            <Volume2 className="w-5 h-5" />
            تشغيل الصفارة
          </Button>
        </div>
      </motion.div>
    </div>
  );
}