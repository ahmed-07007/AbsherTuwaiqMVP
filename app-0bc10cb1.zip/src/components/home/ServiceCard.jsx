import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ServiceCard({ icon: Icon, title, color, page, onClick }) {
  const content = (
    <div className="flex flex-col items-center gap-2 p-4 cursor-pointer transition-all hover:scale-105">
      <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center`}>
        <Icon className="w-7 h-7 text-white" />
      </div>
      <span className="text-xs font-medium text-gray-700 text-center">{title}</span>
    </div>
  );

  if (onClick) {
    return <div onClick={onClick}>{content}</div>;
  }

  return (
    <Link to={createPageUrl(page)}>
      {content}
    </Link>
  );
}