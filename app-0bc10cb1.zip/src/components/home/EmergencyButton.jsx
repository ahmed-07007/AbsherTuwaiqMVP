import React from 'react';
import { Phone } from 'lucide-react';
import { motion } from 'framer-motion';

export default function EmergencyButton({ onClick }) {
  return (
    <motion.button
      onClick={onClick}
      className="relative w-32 h-32 rounded-full bg-gradient-to-br from-red-500 to-red-600 shadow-2xl flex items-center justify-center"
      whileTap={{ scale: 0.95 }}
      animate={{
        boxShadow: [
          '0 0 0 0 rgba(220, 38, 38, 0.4)',
          '0 0 0 20px rgba(220, 38, 38, 0)',
        ],
      }}
      transition={{
        duration: 1.5,
        repeat: Infinity,
        ease: 'easeOut',
      }}
    >
      <div className="absolute inset-2 rounded-full bg-gradient-to-br from-red-400 to-red-600 flex items-center justify-center">
        <Phone className="w-12 h-12 text-white" />
      </div>
    </motion.button>
  );
}